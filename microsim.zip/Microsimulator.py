from GUI import MicrosimGUI

if __name__ == '__main__':
    gui = MicrosimGUI()
    gui.mainloop()
